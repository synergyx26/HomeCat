# Home & Cats — Pet Care App

A cross-platform app for managing your home and cat care, built with React, TailwindCSS, and Expo for mobile compatibility.

## Features
- Food & supply tracking
- Health records (vet visits, vaccinations)
- Issue logging with images
- Pet sitter scheduling
- Responsive web + mobile support

## Run Locally (Web)
```bash
npm install
npm run dev
```

## Run on Mobile
```bash
npm install -g expo-cli
expo start
```

## Deploy to Vercel
- Framework: Vite
- Build Command: `npm run build`
- Output Directory: `dist`
